import { View, Text } from 'react-native'
import React from 'react'

const MembershipPlan = () => {
  return (
    <View>
      <Text>MembershipPlan</Text>
    </View>
  )
}

export default MembershipPlan